"""
Run vulnerability code identification for unfixed vulnerabilities.
"""

from __future__ import annotations
from typing import Dict, Any

import pandas as pd
import os
import json
from src.backend.utils.cmd import run_cmd, run_cmd_and_parse_output
from src.backend.utils.df import append_df, save_df
from dotenv import load_dotenv
import numpy as np

load_dotenv()

GH_TOKEN = os.environ.get("GH_TOKEN", "")
SEMGREP_APP_TOKEN = os.environ.get("SEMGREP_APP_TOKEN", "")
GITHUB_ORG_NAME = "Vuln-Guard"

# Exclude patterns for Semgrep scanning
EXCLUDE_PATTERNS = [
    "test", "tests", "*.test.*", "__tests__",
    "target", "build", "dist", "out",
    "node_modules", "vendor", "packages",
    "*.min.js", "*.bundle.js", "*.min.css",
    "docs", "documentation", "examples", "sample", "samples",
    "*.log", "*.tmp", ".git", ".svn",
    "*.png", "*.jpg", "*.jpeg", "*.gif", "*.svg", "*.ico",
    "*.woff", "*.woff2", "*.ttf", "*.eot",
]

def vuln_code_identify(
        vuln_scan_df: pd.DataFrame, 
        dep_repos_root_dir_path: str,
        output_scans_dir_path: str | None, 
        output_scans_pd_dir_path: str, 
        output_pd_path: str,
        semgrep_jobs: int = 10,
        enable_dataflow_traces: bool = True,
        semgrep_timeout: int = None,
        max_file_size: int = None,
        max_repo_size_mb: int = None) -> pd.DataFrame:
    """
    Run vulnerability code identification for unfixed vulnerabilities.

    Args:
        vuln_scan_df: DataFrame with vulnerability scan results
        dep_repos_root_dir_path: Root directory for cloning repos
        output_scans_dir_path: Directory for raw semgrep JSON outputs
        output_scans_pd_dir_path: Directory for processed parquet outputs
        output_pd_path: Path for final output parquet file
        semgrep_jobs: Number of parallel semgrep jobs (default: 10)
        enable_dataflow_traces: Enable dataflow traces (default: True)
        semgrep_timeout: Timeout per rule in seconds (default: None)
        max_file_size: Max file size to scan in bytes (default: None)
        max_repo_size_mb: Skip repos larger than this size in MB (default: None)

    Returns:
        pd.DataFrame: DataFrame containing vulnerability code identification results.
    """
    # skip if output_pd_path already exists and is non-empty
    if os.path.isfile(output_pd_path) and os.path.getsize(output_pd_path) > 0:
        print(f"Vulnerability code identification dataframe file {output_pd_path} already exists and is non-empty. Skipping vulnerability code identification.")
        return pd.read_parquet(output_pd_path)
    
    print(f"\n{'='*60}")
    print("vuln_code_identify: Starting process")
    print(f"{'='*60}")
    print(f"Input DataFrame: {len(vuln_scan_df)} total vulnerabilities")
    print(f"Parameters:")
    print(f"  semgrep_jobs: {semgrep_jobs}")
    print(f"  enable_dataflow_traces: {enable_dataflow_traces}")
    print(f"  semgrep_timeout: {semgrep_timeout}s")
    print(f"  max_file_size: {max_file_size / 1_000_000 if max_file_size else 'unlimited':.2f}MB" if max_file_size else "  max_file_size: unlimited")
    print(f"  max_repo_size_mb: {max_repo_size_mb}MB" if max_repo_size_mb else "  max_repo_size_mb: unlimited")
    
    # identify unfixed vulnerabilities
    unfixed_vuln_df = vuln_scan_df[vuln_scan_df["fixed_version"].isnull()]
    # identify fixed vulnerabilities
    fixed_vuln_df = vuln_scan_df[vuln_scan_df["fixed_version"].notnull()]
    
    print(f"\nVulnerability breakdown:")
    print(f"  Unfixed (to process): {len(unfixed_vuln_df)}")
    print(f"  Fixed (skip): {len(fixed_vuln_df)}")
    
    if len(unfixed_vuln_df) == 0:
        print("⚠️  No unfixed vulnerabilities found. Nothing to process.")
        return pd.DataFrame()
    
    # Get unique repos
    unique_repos = unfixed_vuln_df['source_code_location'].dropna().unique()
    print(f"\nUnique repositories to scan: {len(unique_repos)}")
    for i, repo in enumerate(unique_repos, 1):
        vuln_count = len(unfixed_vuln_df[unfixed_vuln_df['source_code_location'] == repo])
        print(f"  {i}. {repo} ({vuln_count} vulnerabilities)")

    # initialize output_df to None
    output_df = None
    skipped_unfixed_vulns = []

    # iterate through unfixed vulnerabilities and run code identification
    for _, row in unfixed_vuln_df.iterrows():
        # skip if source_code_location is empty but track the skipped rows so that they can be appended to output_df later
        if not row["source_code_location"]:
            skipped_unfixed_vulns.append(row)
            print(f"Skipping vulnerability cve_id={row['cve_id']}, package_name={row['package_name']}, package_version={row['package_version']} as source_code_location is empty.")
            continue
        
        repo_url = row["source_code_location"] + ".git" # source_code_location is github url without .git
        # extract repo name from github url
        repo_name = repo_url.split("/")[-1].replace(".git", "")
        # derive dir path to clone forked repo into
        dir_path = os.path.join(dep_repos_root_dir_path, repo_name)

        # ensure Vuln-Guard organization personal access token is provided in env vars so that gh CLI can be invoked successfully
        if not GH_TOKEN:
            raise ValueError("GH_TOKEN environment variable not set. Cannot authenticate with GitHub CLI. Please set GH_TOKEN to a valid GitHub personal access token with appropriate permissions.")

        # fork repo to Vuln-Guard organization if not already forked
        is_forked = None
        try:
            repo_info = run_cmd_and_parse_output(["gh", "repo", "view", f"{GITHUB_ORG_NAME}/{repo_name}", '--json', 'isFork'])
            is_forked = repo_info.get("isFork", False)
        except Exception:
            is_forked = False
        if not is_forked:
            run_cmd(["gh", "repo", "fork", repo_url, "--org", GITHUB_ORG_NAME, "--clone=false"])
            print(f"Forked repo {repo_url} to organization {GITHUB_ORG_NAME}")
        else:
            print(f"Repo {repo_name} already forked to organization {GITHUB_ORG_NAME}. Skipping forking.")

        # clone forked repo into dir_path if not already cloned
        forked_repo_url = f"https://github.com/{GITHUB_ORG_NAME}/{repo_name}.git"
        if repo_url and dir_path and (not os.path.exists(dir_path) or not os.listdir(dir_path)):
            run_cmd(["git", "clone", forked_repo_url, dir_path])
            print(f"Cloned repo {forked_repo_url} into {dir_path}")
        else:
            print(f"Repo {forked_repo_url} already cloned in {dir_path}. Skipping cloning.")

        # in order to get semgrep to work we need to tell git to trust the absolute dir_path because under the hood, semgrep runs `git -C <abs_dir_path> ls-files -z --cached`.
        abs_dir_path = os.path.abspath(dir_path)
        run_cmd(["git", "config", "--global", "--add", "safe.directory", abs_dir_path])

        # Check repository size and skip if too large
        import subprocess
        size_output = subprocess.check_output(['du', '-sb', dir_path], text=True)
        repo_size_bytes = int(size_output.split()[0])
        repo_size_mb = repo_size_bytes / (1024 * 1024)
                
        print(f"Repository size: {repo_size_mb:.1f} MB")
                # Continue with scan if size check fails

        # run semgrep scan on the cloned forked repo if corresponding pandas dataframe doesn't already exist
        output_scan_path = os.path.join(output_scans_dir_path, f"{repo_name}_semgrep_scan.json") if output_scans_dir_path else None
        if output_scan_path and os.path.isfile(output_scan_path) and os.path.getsize(output_scan_path) > 0:
            print(f"Semgrep scan output file {output_scan_path} already exists and is non-empty. Skipping semgrep scan.")
            with open(output_scan_path, "r") as f:
                semgrep_scan_result = json.load(f)
        else:
            # note: provide semgrep app token in env vars to get fuller results
            semgrep_scan_result = _run_semgrep_scan(
                dir_path, 
                output_path=output_scan_path,
                num_subprocesses=semgrep_jobs,
                enable_dataflow_traces=enable_dataflow_traces,
                timeout=semgrep_timeout,
                max_file_size=max_file_size
            )
        print("finished semgrep scan.")

        # convert semgrep scan result to pandas dataframe if corresponding pandas dataframe doesn't already exist
        output_scan_pd_path = os.path.join(output_scans_pd_dir_path, f"{repo_name}_semgrep_scan_pd.parquet") if output_scans_pd_dir_path else None
        if output_scan_pd_path and os.path.isfile(output_scan_pd_path) and os.path.getsize(output_scan_pd_path) > 0:
            print(f"Semgrep scan pandas dataframe file {output_scan_pd_path} already exists and is non-empty. Skipping converting semgrep scan to pandas dataframe.")
            result_df = pd.read_parquet(output_scan_pd_path)
        else:
            result_df =  _extract_semgrep_df(semgrep_scan_result, output_path=output_scan_pd_path)
        print("finished converting semgrep scan to pandas dataframe")

        # combine semgrep scan result dataframe with vuln_scan_df on matching cwe_id and filename in summary, description, or references
        cwe_id = row["cwe_id"]
        result_df = result_df[result_df.apply(lambda r: (r['cwe_id'] ==  cwe_id) & any(r['filename'] in str(row[col]) for col in ['summary', 'description', 'references']), axis=1)]
        if not result_df.empty:
            print(f"matching rows found in semgrep scan for vulnerability cve_id={row['cve_id']}: \n {result_df}")
        merged_df = pd.merge(row.to_frame().T, result_df, how='left', on='cwe_id')

        # append merged_df to output_df
        output_df = append_df(output_df, merged_df)

    # append skipped_unfixed_vulns to output_df with NaN values for semgrep columns
    if skipped_unfixed_vulns:
        skipped_unfixed_vulns_df = pd.DataFrame(skipped_unfixed_vulns)
        output_df = append_df(output_df, skipped_unfixed_vulns_df)
    # append fixed_vuln_df to output_df with NaN values for semgrep columns
    if not fixed_vuln_df.empty:
        output_df = append_df(output_df, fixed_vuln_df)
    # save output DataFrame to parquet
    save_df(output_df, output_pd_path)

    return output_df

def _run_semgrep_scan(
    repo_path: str,
    output_path: str,
    num_subprocesses: int = 8,
    timeout: int = 300,
    max_file_size: int = None,  # Can be None
    enable_dataflow_traces: bool = False,
) -> dict:
    """Run Semgrep scan on repository."""
    
    semgrep_cmd = [
        "semgrep",
        "scan",
        repo_path,
        "-j", str(num_subprocesses),
        "--json",
        "--verbose",
        "--metrics=off",
        "--config", "p/default",
        "--timeout", str(timeout),
    ]
    
    # Only add max-target-bytes if specified
    if max_file_size is not None:
        semgrep_cmd.extend(["--max-target-bytes", str(max_file_size)])
    
    # Add dataflow traces if enabled
    if enable_dataflow_traces:
        semgrep_cmd.append("--dataflow-traces")
    
    
    for pattern in EXCLUDE_PATTERNS:
        semgrep_cmd.extend(["--exclude", pattern])
    
    semgrep_cmd.extend(["--json-output", output_path])
    
    return run_cmd_and_parse_output(semgrep_cmd)

def _extract_semgrep_df(semgrep_result: Dict[str, Any], output_path: str) -> pd.DataFrame:
    """
    Extract relevant information from semgrep scan result and convert to pandas DataFrame.

    Args:
        semgrep_result (Dict[str, Any]): Semgrep scan result as a dictionary.

    Returns:
        pd.DataFrame: DataFrame containing relevant semgrep scan information.
    """
    semgrep_df = pd.json_normalize(semgrep_result["results"])
    # if extra.dataflow_trace fields are missing, add them with NaN values
    for col in ['extra.dataflow_trace.taint_source', 'extra.dataflow_trace.intermediate_vars', 'extra.dataflow_trace.taint_sink']:
        if col not in semgrep_df.columns:
            semgrep_df[col] = np.nan
    # extract relevant columns
    relevant_columns = ['path', 'start.line', 'start.col', 'start.offset', 'end.line', 'end.col', 'end.offset', 'extra.message', 'extra.metadata.cwe', "extra.metadata.likelihood", "extra.metadata.impact", "extra.metadata.confidence", "extra.metadata.vulnerability_class", "extra.severity", "extra.lines", "extra.validation_state", "extra.fix", "extra.dataflow_trace.taint_source", "extra.dataflow_trace.intermediate_vars", "extra.dataflow_trace.taint_sink"]
    semgrep_extracted_df = semgrep_df[relevant_columns] 
    semgrep_extracted_df = semgrep_extracted_df.explode(['extra.metadata.cwe'])
    semgrep_extracted_df[['cwe_id', 'cwe_name']] = semgrep_extracted_df['extra.metadata.cwe'].str.split(': ', expand=True)
    semgrep_extracted_df.drop(columns=['cwe_name','extra.metadata.cwe'], inplace=True)
    semgrep_extracted_df = semgrep_extracted_df.explode(['extra.metadata.vulnerability_class'])
    semgrep_extracted_df['filename'] = semgrep_extracted_df['path'].apply(lambda x: x.split('/')[-1].split('.')[0])
    # convert taint_source, intermediate_vars, taint_sink lists to strings
    semgrep_extracted_df['extra_dataflow_trace_taint_source'] = semgrep_extracted_df['extra.dataflow_trace.taint_source'].astype(str)
    semgrep_extracted_df['extra_dataflow_trace_intermediate_vars'] = semgrep_extracted_df['extra.dataflow_trace.intermediate_vars'].astype(str)
    semgrep_extracted_df['extra_dataflow_trace_taint_sink'] = semgrep_extracted_df['extra.dataflow_trace.taint_sink'].astype(str)
    semgrep_extracted_df.drop(columns=['extra.dataflow_trace.taint_source', 'extra.dataflow_trace.intermediate_vars', 'extra.dataflow_trace.taint_sink'], inplace=True)
    # rename columns with dots removed
    semgrep_extracted_df.columns = semgrep_extracted_df.columns.str.replace('.', '_')

    # save to parquet if output_path is provided
    if output_path:
        save_df(semgrep_extracted_df, output_path)
        print(f"Saved semgrep extracted DataFrame to {output_path}")

    return semgrep_extracted_df